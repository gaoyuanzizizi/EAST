import numpy as np
import cv2
import random


class CommonCompose:
    def __init__(self, transforms):
        self.transforms = transforms

    def __call__(self, img):
        for t in self.transforms:
            img = t(img)
        return img


class AutoLevelsAdjustment:
    def __init__(self):
        pass

    def __call__(self, img):
        h, w, d = img.shape
        newimg = np.zeros([h, w, d])
        for i in range(d):
            imghist = np.bincount(img[:, :, i].reshape(1, -1)[0])
            minlevel = self._compute_min_level(imghist, h * w)
            maxlevel = self.__compute_max_level(imghist, h * w)
            screenNum = self.__linear_map(minlevel, maxlevel)
            if screenNum.size == 0:
                continue
            for j in range(h):
                newimg[j, :, i] = screenNum[img[j, :, i]]
        return newimg

    @staticmethod
    def _compute_min_level(hist, pnum):
        index = np.add.accumulate(hist)
        return np.argwhere(index > pnum * 8.3 * 0.01)[0][0]

    @staticmethod
    def __compute_max_level(hist, pnum):
        hist_0 = hist[::-1]
        Iter_sum = np.add.accumulate(hist_0)
        index = np.argwhere(Iter_sum > (pnum * 2.2 * 0.01))[0][0]
        return 255 - index

    @staticmethod
    def __linear_map(minlevel, maxlevel):
        if minlevel >= maxlevel:
            return []
        else:
            index = np.array(list(range(256)))
            screenNum = np.where(index < minlevel, 0, index)
            screenNum = np.where(screenNum > maxlevel, 255, screenNum)
            for i in range(len(screenNum)):
                if 0 < screenNum[i] < 255:
                    screenNum[i] = (i - minlevel) / (maxlevel - minlevel) * 255
            return screenNum


class GaussianBlur:
    def __init__(self, kernel_size, sigma):
        self.kernel_size = kernel_size
        self.sigma = sigma

    def __call__(self, img):
        return cv2.GaussianBlur(img, self.kernel_size, self.sigma)


class SaltNoise:
    def __init__(self, ratio):
        self.ratio = ratio

    def __call__(self, img):
        h, w, d = img.shape
        noise_num = int(h * w * self.ratio)
        for idx in range(noise_num):
            y = random.randint(0, h - 1)
            x = random.randint(0, w - 1)
            flag = random.random()
            if flag < 0.5:
                img[y, x, :] = 0
            else:
                img[y, x, :] = 255

        return img


class Padding:
    def __init__(self, size):
        # size = (width, height)
        self.size = size

    def __call__(self, img):
        img_h, img_w, img_c = img.shape
        (output_w, output_h) = self.size
        if img_w / img_h > output_w / output_h:
            ratio = output_w / img_w
            resize_w = output_w
            resize_h = int(img_h * ratio)
            top_pad = int((output_h - resize_h) / 2)
            left_pad = 0

        else:
            ratio = output_h / img_h
            resize_w = int(img_w * ratio)
            resize_h = output_h
            top_pad = 0
            left_pad = int((output_w - resize_w) / 2)
        output_img = np.zeros((output_h, output_w, img_c), dtype=np.uint8)
        img = cv2.resize(img, (resize_w, resize_h))
        output_img[top_pad:top_pad + resize_h, left_pad:left_pad + resize_w, :] = img
        return output_img


if __name__ == '__main__':
    img_path = '/home/gaoyuanzi/Documents/test_model_helper/input.jpg'
    ala = Padding((1024, 768))
    img = cv2.imread(img_path)
    img = ala(img)
    cv2.imwrite('/home/gaoyuanzi/Documents/test_model_helper/output.jpg', img)
