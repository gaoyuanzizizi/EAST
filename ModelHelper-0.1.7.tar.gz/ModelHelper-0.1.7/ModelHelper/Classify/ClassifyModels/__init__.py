from ModelHelper.Classify.ClassifyModels.AbstractModels import ResnetClassifyModel


class Resnet18ClassifyModel(ResnetClassifyModel):
    def __init__(self, **kwargs):
        kwargs['backbone'] = 'resnet18'
        super(Resnet50ClassifyModel, self).__init__(**kwargs)

    def forward(self, **kwargs):
        return super(Resnet50ClassifyModel, self).forward(**kwargs)


class Resnet50ClassifyModel(ResnetClassifyModel):
    def __init__(self, **kwargs):
        kwargs['backbone'] = 'resnet50'
        super(Resnet50ClassifyModel, self).__init__(**kwargs)

    def forward(self, **kwargs):
        return super(Resnet50ClassifyModel, self).forward(**kwargs)


class Resnet101ClassifyModel(ResnetClassifyModel):
    def __init__(self, **kwargs):
        kwargs['backbone'] = 'resnet101'
        super(Resnet50ClassifyModel, self).__init__(**kwargs)

    def forward(self, **kwargs):
        return super(Resnet50ClassifyModel, self).forward(**kwargs)


class Resnet152ClassifyModel(ResnetClassifyModel):
    def __init__(self, **kwargs):
        kwargs['backbone'] = 'resnet152'
        super(Resnet50ClassifyModel, self).__init__(**kwargs)

    def forward(self, **kwargs):
        return super(Resnet50ClassifyModel, self).forward(**kwargs)
