from setuptools import setup
import os


def add_static_files(files_root):
    file_list = list()
    for root, dirs, files in os.walk(files_root):
        for file in files:
            file_path = os.path.join(root, file)
            file_list.append(file_path)
    return file_list


# 需要将那些包导入
packages = ["ModelHelper",
            "ModelHelper.Classify",
            "ModelHelper.Classify.ClassifyModels",
            "ModelHelper.Classify.ClassifyUtils",
            "ModelHelper.Common",
            "ModelHelper.Common.CommonModels",
            "ModelHelper.Common.CommonUtils",
            "ModelHelper.Detection",
            "ModelHelper.Detection.DetectionUtils",
            "ModelHelper.Detection.DetectionModels",
            "ModelHelper.Detection.DetectionModels.east_eval",
            "ModelHelper.Detection.Component"
            ]

# 导入静态文件
file_data = list()
lanms_files = add_static_files("ModelHelper/Detection/Component/lanms")
file_data.extend(lanms_files)

geo_map_files = add_static_files("ModelHelper/Detection/Component/geo_map_cython_lib")
file_data.extend(geo_map_files)

# 第三方依赖
requires = [
    "torch>=0.4.0",
    "opencv-python>=3.4.3.18",
    "Pillow>=5.3.0",
    "torchvision>=0.2.1",
    "Shapely>=1.6.4"
]

setup(
    name='ModelHelper',  # 包名称
    version='0.1.5',  # 包版本
    description='run east detection model successfully',  # 包详细描述
    long_description='2019-10-09 run east detection model successfully;'
                     '2019-10-10 修改config装饰器,将config文件放入output_folder中;',  # 长描述，通常是readme，打包到PiPy需要
    author='gaoyuan',  # 作者名称
    author_email='1015165757@qq.com',  # 作者邮箱
    url='',  # 项目官网
    packages=packages,  # 项目需要的包
    data_files=file_data,  # 打包时需要打包的数据文件，如图片，配置文件等
    include_package_data=True,  # 是否需要导入静态数据文件
    python_requires=">=3.0, !=3.0.*, !=3.1.*, !=3.2.*, !=3.3*",  # Python版本依赖
    install_requires=requires,  # 第三方库依赖
    zip_safe=False,  # 此项需要，否则卸载时报windows error
    classifiers=[  # 程序的所属分类列表
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'Natural Language :: English',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
    ],
)
