import torch.nn as nn
import torch
import math
from ModelHelper.Common.CommonUtils import get, get_valid
from ModelHelper.Common.CommonModels.ModelFactory import BackboneFactory


class AbstractDetectionModel(nn.Module):
    def __init__(self, **kwargs):
        super(AbstractDetectionModel, self).__init__()
        backbone = get_valid('backbone', kwargs)
        backbone_factory = BackboneFactory()
        kwargs['model_name'] = backbone
        self.backbone = backbone_factory.get_model(**kwargs)

    def forward(self, **kwargs):
        pass


class EastDetectionModel(AbstractDetectionModel):
    def __init__(self, **kwargs):
        kwargs['get_layer1_feature'] = True
        kwargs['get_layer2_feature'] = True
        kwargs['get_layer3_feature'] = True
        kwargs['get_layer4_feature'] = True
        super(EastDetectionModel, self).__init__(**kwargs)
        channels = get('channels', kwargs, [2656, 960, 384])
        self.detection_size = get('detection_size', kwargs, 768)

        self.conv1_in_channels = channels[0]
        self.conv3_in_channels = channels[1]
        self.conv5_in_channels = channels[2]

        self.conv1 = nn.Conv2d(self.conv1_in_channels, 128, 1)
        self.bn1 = nn.BatchNorm2d(128, momentum=0.9)
        self.relu1 = nn.ReLU()

        self.conv2 = nn.Conv2d(128, 128, 3, padding=1)
        self.bn2 = nn.BatchNorm2d(128, momentum=0.9)
        self.relu2 = nn.ReLU()

        self.conv3 = nn.Conv2d(self.conv3_in_channels, 64, 1)
        self.bn3 = nn.BatchNorm2d(64, momentum=0.9)
        self.relu3 = nn.ReLU()

        self.conv4 = nn.Conv2d(64, 64, 3, padding=1)
        self.bn4 = nn.BatchNorm2d(64, momentum=0.9)
        self.relu4 = nn.ReLU()

        self.conv5 = nn.Conv2d(self.conv5_in_channels, 64, 1)
        self.bn5 = nn.BatchNorm2d(64, momentum=0.9)
        self.relu5 = nn.ReLU()

        self.conv6 = nn.Conv2d(64, 32, 3, padding=1)
        self.bn6 = nn.BatchNorm2d(32, momentum=0.9)
        self.relu6 = nn.ReLU()

        self.conv7 = nn.Conv2d(32, 32, 3, padding=1)
        self.bn7 = nn.BatchNorm2d(32, momentum=0.9)
        self.relu7 = nn.ReLU()

        self.conv8 = nn.Conv2d(32, 1, 1)
        self.sigmoid = nn.Sigmoid()
        self.conv9 = nn.Conv2d(32, 4, 1)
        self.conv10 = nn.Conv2d(32, 1, 1)

        self.uppool1 = nn.Upsample(scale_factor=2, mode='bilinear')
        self.uppool2 = nn.Upsample(scale_factor=2, mode='bilinear')
        self.uppool3 = nn.Upsample(scale_factor=2, mode='bilinear')

    def forward(self, **kwargs):
        super(EastDetectionModel, self).forward(**kwargs)
        image = get_valid('image', kwargs)
        feature_list = self.backbone(image)

        h = feature_list[3]
        g = self.uppool1(h)
        c = self.conv1(torch.cat((g, feature_list[2]), 1))
        c = self.bn1(c)
        c = self.relu1(c)

        h = self.conv2(c)
        h = self.bn2(h)
        h = self.relu2(h)

        g = self.uppool2(h)
        c = self.conv3(torch.cat((g, feature_list[1]), 1))
        c = self.bn3(c)
        c = self.relu3(c)

        h = self.conv4(c)  # bs 64 w/8 h/8
        h = self.bn4(h)
        h = self.relu4(h)
        g = self.uppool3(h)  # bs 64 w/4 h/4
        c = self.conv5(torch.cat((g, feature_list[0]), 1))
        c = self.bn5(c)
        c = self.relu5(c)

        h = self.conv6(c)  # bs 32 w/4 h/4
        h = self.bn6(h)
        h = self.relu6(h)
        g = self.conv7(h)  # bs 32 w/4 h/4
        g = self.bn7(g)
        g = self.relu7(g)

        F_score = self.conv8(g)  # bs 1 w/4 h/4
        F_score = self.sigmoid(F_score)
        geo_map = self.conv9(g)
        geo_map = self.sigmoid(geo_map) * self.detection_size
        angle_map = self.conv10(g)
        angle_map = self.sigmoid(angle_map)
        angle_map = (angle_map - 0.5) * math.pi / 2

        F_geometry = torch.cat((geo_map, angle_map), 1)  # bs 5 w/4 w/4
        return F_score, F_geometry


