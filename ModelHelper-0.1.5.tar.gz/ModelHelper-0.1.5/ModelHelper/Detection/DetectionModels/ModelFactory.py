from ModelHelper.Detection import DetectionModels
from ModelHelper.Common.CommonModels.ModelFactory import AbstractModelFactory


class DetectionModelFactory(AbstractModelFactory):
    def __init__(self, **kwargs):
        super(DetectionModelFactory, self).__init__(model_file=DetectionModels, **kwargs)

    def get_model(self, **kwargs):
        return super(DetectionModelFactory, self).get_model(**kwargs)
