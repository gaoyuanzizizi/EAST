from ModelHelper.Common.CommonUtils import get, get_valid
from ModelHelper.Common.CommonUtils.HandleImage import get_img_list
from ModelHelper.Detection.Component import lanms
# from ModelHelper.Detection.DetectionModels.Template import EastDetectionTemplate
from ModelHelper.Detection.DetectionUtils.Evaluation import f1score
from ModelHelper.Detection.DetectionModels.east_eval.data_utils import restore_rectangle, polygon_area
import cv2
import time
import os
import numpy as np
import torch


def resize_image(im, max_side_len=2400):
    '''
    resize image to a size multiple of 32 which is required by the network
    :param im: the resized image
    :param max_side_len: limit of max image size to avoid out of memory in gpu
    :return: the resized image and the resize ratio
    '''
    h, w, _ = im.shape

    resize_w = w
    resize_h = h

    # limit the max side
    """
    if max(resize_h, resize_w) > max_side_len:
        ratio = float(max_side_len) / resize_h if resize_h > resize_w else float(max_side_len) / resize_w
    else:
        ratio = 1.

    resize_h = int(resize_h * ratio)
    resize_w = int(resize_w * ratio)
    """

    resize_h = resize_h if resize_h % 32 == 0 else (resize_h // 32 - 1) * 32
    resize_w = resize_w if resize_w % 32 == 0 else (resize_w // 32 - 1) * 32
    # resize_h, resize_w = 512, 512
    im = cv2.resize(im, (int(resize_w), int(resize_h)))

    ratio_h = resize_h / float(h)
    ratio_w = resize_w / float(w)

    return im, (ratio_h, ratio_w)


def detect(score_map, geo_map, score_map_thresh=0.7, box_thresh=0.1, nms_thresh=0.2):
    '''
    restore text boxes from score map and geo map
    :param score_map:
    :param geo_map:
    :param score_map_thresh: threshhold for score map
    :param box_thresh: threshhold for boxes
    :param nms_thres: threshold for nms
    :return:
    '''
    if len(score_map.shape) == 4:
        score_map = score_map[0, :, :, 0]
        geo_map = geo_map[0, :, :, ]
    # filter the score map
    xy_text = np.argwhere(score_map > score_map_thresh)
    # sort the text boxes via the y axis
    xy_text = xy_text[np.argsort(xy_text[:, 0])]
    # restore
    start = time.time()
    text_box_restored = restore_rectangle(xy_text[:, ::-1] * 4, geo_map[xy_text[:, 0], xy_text[:, 1], :])  # N*4*2
    # print('{} text boxes before nms'.format(text_box_restored.shape[0]))
    boxes = np.zeros((text_box_restored.shape[0], 9), dtype=np.float32)
    boxes[:, :8] = text_box_restored.reshape((-1, 8))
    boxes[:, 8] = score_map[xy_text[:, 0], xy_text[:, 1]]
    # nms part
    start = time.time()
    # boxes = nms_locality.nms_locality(boxes.astype(np.float64), nms_thres)
    boxes = lanms.merge_quadrangle_n9(boxes.astype('float32'), nms_thresh)
    if boxes.shape[0] == 0:
        return None

    # here we filter some low score boxes by the average score map, this is different from the orginal paper
    for i, box in enumerate(boxes):
        mask = np.zeros_like(score_map, dtype=np.uint8)
        cv2.fillPoly(mask, box[:8].reshape((-1, 4, 2)).astype(np.int32) // 4, 1)
        boxes[i, 8] = cv2.mean(score_map, mask)[0]
    boxes = boxes[boxes[:, 8] > box_thresh]
    return boxes


def sort_poly(p):
    min_axis = np.argmin(np.sum(p, axis=1))
    p = p[[min_axis, (min_axis + 1) % 4, (min_axis + 2) % 4, (min_axis + 3) % 4]]
    if abs(p[0, 0] - p[1, 0]) > abs(p[0, 1] - p[1, 1]):
        return p
    else:
        return p[[0, 3, 2, 1]]

#
# def predict(**kwargs):
#     label_folder = get_valid('label_folder', kwargs)
#     pred_folder = get_valid('pred_folder', kwargs)
#     template = EastDetectionTemplate(**kwargs)
#     model = template.init_model(**kwargs)
#     model, _, _, _ = template.load_model(mdoel=model, **kwargs)
#     test_loader = template.init_testloader(**kwargs)
#     with torch.no_grad():
#         for idx, (img, score_map, geo_map, training_mask) in enumerate(test_loader):
#             if self.gpu is not None:
#                 img = img.cuda()
#                 score_map = score_map.cuda()
#                 geo_map = geo_map.cuda()
#                 training_mask = training_mask.cuda()
#
#             f_score, f_geometry = model(image=img)
#
#     img_list = get_img_list(label_folder)
#     for img in img_list:
#         img_path = os.path.join(label_folder, img)
#         image = cv2.imread(img_path)
#
#         im_resized, (ratio_h, ratio_w) = resize_image(image)
#         im_resized = im_resized.astype(np.float32)
#
#         # im_resized = transform(image)
#         im_resized = im_resized.transpose(2, 0, 1)
#         im_resized = torch.from_numpy(im_resized)
#         im_resized = im_resized.cuda()
#         im_resized = im_resized.unsqueeze(0)
#         # im_resized = im_resized.permute(0, 3, 1, 2)
#
#         timer = {'net': 0, 'restore': 0, 'nms': 0}
#         start = time.time()
#
#         score, geometry = model(im_resized)
#
#         timer['net'] = time.time() - start
#         print('EAST <==> TEST <==> idx:{} <==> model  :{:.2f}ms'.format(idx, timer['net'] * 1000))
#
#         score = score.permute(0, 2, 3, 1)
#         geometry = geometry.permute(0, 2, 3, 1)
#         score = score.data.cpu().numpy()
#         geometry = geometry.data.cpu().numpy()
#
#         boxes, timer = detect(score_map=score, geo_map=geometry, timer=timer)
#         print('EAST <==> TEST <==> idx:{} <==> restore:{:.2f}ms'.format(idx, timer['restore'] * 1000))
#         print('EAST <==> TEST <==> idx:{} <==> nms    :{:.2f}ms'.format(idx, timer['nms'] * 1000))
#
#         print('EAST <==> TEST <==> Record and Save <==> id:{} <==> Begin'.format(idx))
#         if boxes is not None:
#             boxes = boxes[:, :8].reshape((-1, 4, 2))
#             boxes[:, :, 0] /= ratio_w
#             boxes[:, :, 1] /= ratio_h
#
#         if boxes is not None:
#             res_file = os.path.join(output_dir_txt,
#                                     'res_img_{}.txt'.format(os.path.basename(im_fn).split('_')[-1].strip('.jpg')))
#             with open(res_file, 'w') as f:
#                 for box in boxes:
#                     box = sort_poly(box.astype(np.int32))
#
#                     if np.linalg.norm(box[0] - box[1]) < 5 or np.linalg.norm(box[3] - box[0]) < 5:
#                         # print('wrong direction')
#                         continue
#
#                     if box[0, 0] < 0 or box[0, 1] < 0 or box[1, 0] < 0 or box[1, 1] < 0 or box[2, 0] < 0 or box[
#                         2, 1] < 0 or box[3, 0] < 0 or box[3, 1] < 0:
#                         continue
#
#                     poly = np.array([[box[0, 0], box[0, 1]], [box[1, 0], box[1, 1]], [box[2, 0], box[2, 1]],
#                                      [box[3, 0], box[3, 1]]])
#
#                     p_area = polygon_area(poly)
#                     if p_area > 0:
#                         poly = poly[(0, 3, 2, 1), :]
#
#                     f.write(
#                         '{},{},{},{},{},{},{},{}\r\n'.format(poly[0, 0], poly[0, 1], poly[1, 0], poly[1, 1], poly[2, 0],
#                                                              poly[2, 1], poly[3, 0], poly[3, 1], ))
#                     cv2.polylines(im[:, :, ::-1], [box.astype(np.int32).reshape((-1, 1, 2))], True, color=(255, 255, 0),
#                                   thickness=1)
#
#         save_img_path = os.path.join(output_dir_pic, os.path.basename(im_fn))
#         cv2.imwrite(save_img_path, im[:, :, ::-1])
#         print('EAST <==> TEST <==> Save txt   at:{} <==> Done'.format(res_file))
#         print('EAST <==> TEST <==> Save image at:{} <==> Done'.format(save_img_path))
#
#         print('EAST <==> TEST <==> Record and Save <==> ids:{} <==> Done'.format(idx))
#     return output_dir_txt


# if __name__ == "__main__":
#     predict()
