import random
from multiprocessing import Pool


def get(key, kwargs, default=None):
    if key in kwargs:
        return kwargs[key]
    else:
        return default


def get_valid(key, kwargs):
    if key not in kwargs:
        raise RuntimeError('has no {} key in kwargs!'.format(key))
    return kwargs[key]


def generate_log(epoch, name='', **kwargs):
    log = '{}: {}th epoch'.format(name, epoch)
    for key in kwargs:
        log_item = ', {}: {}'.format(key, kwargs[key])
        log += log_item
    log += '\n'
    return log


def handle_data_multiprocess(**kwargs):
    data_list = get_valid('data_list', kwargs)
    func = get_valid('func', kwargs)
    worker_num = get_valid('worker_num', kwargs)

    total_list = list()
    p = Pool(worker_num)

    for idx in range(worker_num):
        process_list = list()
        total_list.append(process_list)

    for data in data_list:
        rand = random.randint(0, worker_num - 1)
        total_list[rand].append(data)

    for idx in range(worker_num):
        p.apply(func, args=(total_list[rand]))
    p.close()
    p.join()
