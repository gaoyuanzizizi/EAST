import os
from PIL import Image
import numpy as np
import copy
import cv2
import random
import shutil


def copy_img_infolder(src_folder, desc_folder):
    img_list = get_img_list(src_folder)
    for img in img_list:
        src_img = os.path.join(src_folder, img)
        desc_img = os.path.join(desc_folder, img)
        shutil.copy(src_img, desc_img)


def get_img_list(img_folder):
    img_list = list()
    for root, dirs, files in os.walk(img_folder):
        for file in files:
            file_path = os.path.join(root, file)
            if is_valid_img(file_path):
                img_list.append(file)
    return img_list


def is_valid_img(img_path):
    try:
        Image.open(img_path).verify()
        img = Image.open(img_path)
        if img is None:
            return False
        height = img.size[0]
        width = img.size[1]
        if height == 0 or width == 0:
            return False
    except:
        return False
    return True


def cv2pil(img):
    tmp_img = copy.deepcopy(img)
    b = tmp_img[:, :, 0]
    g = tmp_img[:, :, 1]
    r = tmp_img[:, :, 2]
    img[:, :, 0] = r
    img[:, :, 1] = g
    img[:, :, 2] = b

    img = img.astype(np.uint8)
    img = Image.fromarray(img)
    return img


def pil2cv(img):
    img = np.array(img)
    tmp_img = copy.deepcopy(img)
    r = tmp_img[:, :, 0]
    g = tmp_img[:, :, 1]
    b = tmp_img[:, :, 2]

    img[:, :, 0] = b
    img[:, :, 1] = g
    img[:, :, 2] = r
    return img


def padding(img, size):
    (height, width) = size
    img_height = img.shape[0]
    img_width = img.shape[1]
    channel = img.shape[3]

    img_whratio = img_width / img_height
    whratio = width / height
    output_img = np.zeros((height, width, channel))
    # pad top and bottom
    if img_whratio > whratio:
        resize_ratio = width / img_width
        resize_height = img_height * resize_ratio
        resize_img = cv2.resize(img, (width, resize_height))
        pad_top = int((resize_height - img_height) / 2)
        pad_left = 0
        output_img[pad_top: pad_top + resize_height, :, :] = resize_img

    else:
        resize_ratio = height / img_height
        resize_width = img_width * resize_ratio
        resize_img = cv2.resize(img, (resize_width, height))
        pad_top = 0
        pad_left = int((resize_width - img_width) / 2)
        output_img[:, pad_left:pad_left + resize_width, :] = resize_img
    return output_img, pad_top, pad_left


def sp_noise(image,prob):
    '''
    添加椒盐噪声
    prob:噪声比例
    '''
    output = np.zeros(image.shape,np.uint8)
    thres = 1 - prob
    for i in range(image.shape[0]):
        for j in range(image.shape[1]):
            rdn = random.random()
            if rdn < prob:
                output[i][j] = 0
            elif rdn > thres:
                output[i][j] = 255
            else:
                output[i][j] = image[i][j]
    return output


def gasuss_noise(image, mean=0, var=0.001):
    '''
        添加高斯噪声
        mean : 均值
        var : 方差
    '''
    image = np.array(image/255, dtype=float)
    noise = np.random.normal(mean, var ** 0.5, image.shape)
    out = image + noise
    if out.min() < 0:
        low_clip = -1.
    else:
        low_clip = 0.
    out = np.clip(out, low_clip, 1.0)
    out = np.uint8(out*255)
    #cv.imshow("gasuss", out)
    return out


if __name__ == '__main__':
    img = '/home/gaoyuanzi/Documents/test_model_helper/data/test_aug/1.jpg'
    img = sp_noise(img)
    cv2.imwrite('sp_noise.png', img)
