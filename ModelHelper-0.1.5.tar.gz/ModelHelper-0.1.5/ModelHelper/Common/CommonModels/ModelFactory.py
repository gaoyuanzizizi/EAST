from ModelHelper.Common import CommonModels
from ModelHelper.Common.CommonUtils import get_valid


class AbstractModelFactory:
    def __init__(self, **kwargs):
        self.model_file = get_valid('model_file', kwargs)

    def get_model(self, **kwargs):
        model_name = get_valid('model_name', kwargs)
        model = getattr(self.model_file, model_name)
        return model(**kwargs)


class BackboneFactory(AbstractModelFactory):
    def __init__(self, **kwargs):
        kwargs['model_file'] = CommonModels
        super(BackboneFactory, self).__init__(**kwargs)

    def get_model(self, **kwargs):
        return super(BackboneFactory, self).get_model(**kwargs)
